import numpy as np
import cv2
from math import log10, sqrt

def mse(img1, img2):
    return np.mean((img1.astype(np.float32) - img2.astype(np.float32)) ** 2)

def psnr(img1, img2):
    mse_val = mse(img1, img2)
    return float('inf') if mse_val == 0 else 20 * log10(255.0 / sqrt(mse_val))

if __name__ == "__main__":
    original = cv2.imread("lena.png", cv2.IMREAD_GRAYSCALE)
    recovered = cv2.imread("recovered_from_collusion.png", cv2.IMREAD_GRAYSCALE)

    if original.shape != recovered.shape:
        recovered = cv2.resize(recovered, (original.shape[1], original.shape[0]))

    diff = cv2.absdiff(original, recovered)
    cv2.imwrite("collusion_diff.png", cv2.convertScaleAbs(diff, alpha=3))

    print(f"📏 MSE: {mse(original, recovered):.2f}")
    print(f"📶 PSNR: {psnr(original, recovered):.2f} dB")
    print("✅ Difference image saved as 'collusion_diff.png'")
