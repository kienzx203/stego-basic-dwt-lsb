import numpy as np
import pywt
import cv2
import os

def dwt2(image):
    image = image.astype(np.float64)
    return pywt.dwt2(image, 'haar')

def idwt2(coeffs):
    return np.clip(pywt.idwt2(coeffs, 'haar'), 0, 255).astype(np.uint8)

def collusion_attack(images):
    HH_all = [dwt2(img)[1][2] for img in images]
    return np.mean(HH_all, axis=0)

def recover_image(HH_avg, reference_img):
    LL, (LH, HL, _) = dwt2(reference_img)
    return idwt2((LL, (LH, HL, HH_avg)))

if __name__ == "__main__":
    img_paths = [f"collusion_noise_images/stego_user_{i}.png" for i in range(10)]
    stego_images = [cv2.imread(p, cv2.IMREAD_GRAYSCALE) for p in img_paths]

    HH_avg = collusion_attack(stego_images)
    recovered = recover_image(HH_avg, stego_images[0])
    cv2.imwrite("recovered_from_collusion.png", recovered)

    print("✅ Recovered image saved as 'recovered_from_collusion.png'")
