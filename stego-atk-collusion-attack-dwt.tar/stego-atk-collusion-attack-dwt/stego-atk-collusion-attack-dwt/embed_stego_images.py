import numpy as np
import pywt
import cv2
import os

def dwt2(image):
    image = image.astype(np.float64)
    return pywt.dwt2(image, 'haar')

def idwt2(coeffs):
    return np.clip(pywt.idwt2(coeffs, 'haar'), 0, 255).astype(np.uint8)

def embed_noise_watermark(image, seed, alpha=100):
    LL, (LH, HL, HH) = dwt2(image)
    np.random.seed(seed)
    watermark = np.random.randn(*HH.shape)
    HH_wm = HH + alpha * watermark
    return idwt2((LL, (LH, HL, HH_wm)))

if __name__ == "__main__":
    image = cv2.imread("lena.png", cv2.IMREAD_GRAYSCALE)
    if image is None:
        raise FileNotFoundError("lena.png not found.")
    image = cv2.resize(image, (256, 256))

    os.makedirs("collusion_noise_images", exist_ok=True)

    for i in range(10):
        stego = embed_noise_watermark(image, seed=i, alpha=150)
        cv2.imwrite(f"collusion_noise_images/stego_user_{i}.png", stego)

    print("✅ Stego images generated in 'collusion_noise_images/'")
