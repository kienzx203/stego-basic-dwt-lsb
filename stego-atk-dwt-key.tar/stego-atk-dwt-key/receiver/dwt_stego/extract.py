"""Extract a secret message from a stego image produced by embed_message."""
from pathlib import Path
from typing import Union, Optional
import numpy as np
import pywt
from PIL import Image
from .utils import bits2str, permute_idx


def extract_message(
    stego_path: Union[str, Path],
    key: int,
    msg_len_bytes: Optional[int] = None,
    *,
    wavelet: str = "haar",
    level: int = 2,
    subband: str = "HL",
    Q: int = 20,
) -> str:
    """
    Recover a hidden UTF-8 message from `stego_path` using the provided secret `key`.

    Parameters
    ----------
    stego_path : str or Path
        Path to the stego image containing the embedded message.
    key : int
        Secret key used to reconstruct the permutation order.
    msg_len_bytes : int or None, optional
        Number of bytes expected in the hidden message (if known). If None, assume max.
    wavelet : str
        Type of wavelet used during embedding. Default is "haar".
    level : int
        Number of DWT decomposition levels. Default is 2.
    subband : str
        Sub-band used for embedding: "LH", "HL", or "HH". Default is "HL".
    Q : int
        Quantization step used during embedding. Default is 20.

    Returns
    -------
    str
        The extracted UTF-8 message.
    """
    # 1) Load image and apply DWT
    img = np.asarray(Image.open(stego_path).convert("L"), dtype=np.float32)
    coeffs = pywt.wavedec2(img, wavelet, level=level)

    # 2) Select the correct subband (same as used in embedding)
    target_idx = {"LH": 0, "HL": 1, "HH": 2}[subband]
    band = coeffs[level][target_idx].flatten()

    # 3) Regenerate the same permutation order using the secret key
    order = permute_idx(band.size, key)

    # 4) Determine the number of bits to extract
    max_bytes = msg_len_bytes or 0xFFFF  # max 65535 bytes
    total_bits = 32 + max_bytes * 8
    if total_bits > band.size:
        raise ValueError("Sub-band is too small for the assumed payload length.")

    bits = np.zeros(total_bits, dtype=np.uint8)

    # 5) Extract bits based on quantization remainder thresholds
    q1, q3 = Q / 4, 3 * Q / 4
    for k in range(total_bits):
        rem = band[order[k]] % Q
        bits[k] = 1 if q1 <= rem < q3 else 0

    # 6) Read 32-bit header for true message length
    real_len = np.packbits(bits[:32]).view(">u4")[0]
    if msg_len_bytes and real_len != msg_len_bytes:
        print("[!] Warning: provided length does not match embedded length.")

    data_bits = bits[32 : 32 + real_len * 8]
    return bits2str(data_bits)
