"""Command-line helper for quick testing & attacking."""
import sys, pathlib
sys.path.append(str(pathlib.Path(__file__).resolve().parent.parent))

import argparse
from dwt_stego import (
    extract_message
)

parser = argparse.ArgumentParser(description="DWT Stego Demo & Attack")
sub = parser.add_subparsers(dest="cmd", required=True)


# --- EXTRACT -----------------------------------------------------------
p_extract = sub.add_parser("extract", help="Extract with known key")
p_extract.add_argument("stego")
p_extract.add_argument("key", type=int)
p_extract.add_argument("length", type=int, nargs="?", default=None)


args = parser.parse_args()

if args.cmd == "extract":
    txt = extract_message(args.stego, args.key, args.length)
    print("Recovered:", txt)

