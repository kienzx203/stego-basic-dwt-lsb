"""Command-line helper for quick testing & attacking."""
import sys, pathlib
sys.path.append(str(pathlib.Path(__file__).resolve().parent.parent))   # bảo đảm tìm thấy package

import argparse
from dwt_stego import (
    embed_message,
    extract_message,
    chi_square_stat,
    brute_force_extract,      # ← MỚI
)

parser = argparse.ArgumentParser(description="DWT Stego Demo & Attack")
sub = parser.add_subparsers(dest="cmd", required=True)

# --- EMBED -------------------------------------------------------------
p_embed = sub.add_parser("embed", help="Hide a message")
p_embed.add_argument("cover")
p_embed.add_argument("output")
p_embed.add_argument("message")
p_embed.add_argument("--key-bits", type=int, default=128,    # ← MỚI
                     help="size of secret key in bits (default 128)")

# --- EXTRACT -----------------------------------------------------------
p_extract = sub.add_parser("extract", help="Extract with known key")
p_extract.add_argument("stego")
p_extract.add_argument("key", type=int)
p_extract.add_argument("length", type=int, nargs="?", default=None)

# --- χ² STAT -----------------------------------------------------------
p_stat = sub.add_parser("stat", help="Chi-square residue test")
p_stat.add_argument("image")

# --- BRUTE-FORCE -------------------------------------------------------
p_brute = sub.add_parser("brute", help="Brute-force key (demo)")
p_brute.add_argument("stego")
p_brute.add_argument("length", type=int)
p_brute.add_argument("--max-key", type=int, default=1 << 16,
                     help="highest key to try (default 65 536)")

args = parser.parse_args()

# ----------------- DISPATCH -------------------------------------------
if args.cmd == "embed":
    embed_message(args.cover, args.message, args.output, key_bits=args.key_bits)

elif args.cmd == "extract":
    txt = extract_message(args.stego, args.key, args.length)
    print("Recovered:", txt)

elif args.cmd == "stat":
    print("Chi-square:", chi_square_stat(args.image))

elif args.cmd == "brute":
    k, msg = brute_force_extract(args.stego, args.length, max_key=args.max_key)
    if k is None:
        print("Brute-force failed up to", args.max_key)
    else:
        print("Key:", k)
        print("Msg:", msg)
