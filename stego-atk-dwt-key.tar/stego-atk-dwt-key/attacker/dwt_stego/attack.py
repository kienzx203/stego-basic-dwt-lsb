"""Simple steganalysis helpers (χ² detector + optimized brute-force)."""
from __future__ import annotations
from typing import Union
import numpy as np, string
from pathlib import Path
import pywt
from PIL import Image
from dwt_stego.extract import extract_message   # delayed import to avoid circular dependency
from dwt_stego.utils   import permute_idx

# ------------------------------------------------------------------
# 1. χ² DETECTOR (statistical analysis to detect modification)
# ------------------------------------------------------------------
def chi_square_stat(
    img_path: Union[str, Path],
    *,
    wavelet: str = "haar",
    level: int = 2,
    subband: str = "HL",
    Q: int = 20,
) -> float:
    """
    Compute chi-square statistic over mod-Q histogram of a DWT subband.

    Parameters
    ----------
    img_path : str or Path
        Path to the image.
    wavelet : str
        Wavelet name (default: 'haar').
    level : int
        DWT decomposition level.
    subband : str
        Subband to analyze: 'LH', 'HL', or 'HH'.
    Q : int
        Quantization step.

    Returns
    -------
    float
        Chi-square value.
    """
    img = np.asarray(Image.open(img_path).convert("L"), dtype=np.float32)
    coeffs = pywt.wavedec2(img, wavelet, level=level)
    band = coeffs[level][{"LH": 0, "HL": 1, "HH": 2}[subband]].flatten()
    hist, _ = np.histogram(np.mod(band, Q), bins=Q, range=(0, Q))
    expected = np.mean(hist)
    return float(np.sum((hist - expected) ** 2 / (expected + 1e-9)))

# ------------------------------------------------------------------
# 2. BRUTE-FORCE SECRET KEY (optimized version)
# ------------------------------------------------------------------
def brute_force_extract(
    stego_path: Union[str, Path],
    msg_len_bytes: int,
    *,
    wavelet: str = "haar",
    level: int = 2,
    subband: str = "HL",
    Q: int = 20,
    max_key: int = 1 << 16,
):
    """
    Attempt to brute-force the secret key in range [0, max_key),
    assuming message length is known. DWT is computed once for speed.

    Parameters
    ----------
    stego_path : str or Path
        Path to the stego image.
    msg_len_bytes : int
        Expected message length in bytes.
    wavelet : str
        Wavelet type used (default: 'haar').
    level : int
        DWT level (default: 2).
    subband : str
        Subband used during embedding ('LH', 'HL', or 'HH').
    Q : int
        Quantization step used during embedding.
    max_key : int
        Upper bound for key search (default: 65536).

    Returns
    -------
    tuple (key, msg) or (None, None)
        Returns a tuple of the correct key and extracted message if successful.
        Otherwise, returns (None, None).
    """
    # 1) Read image and compute DWT once
    img = np.asarray(Image.open(stego_path).convert("L"), dtype=np.float32)
    coeffs = pywt.wavedec2(img, wavelet, level=level)
    target_idx = {"LH": 0, "HL": 1, "HH": 2}[subband]
    band_flat = coeffs[level][target_idx].flatten()

    # 2) Set quantization thresholds
    q1, q3 = Q / 4, 3 * Q / 4

    # 3) Try all keys from 0 to max_key
    for key in range(max_key):
        order = permute_idx(band_flat.size, key)
        bits = []
        for idx in order[: 32 + msg_len_bytes * 8]:
            rem = band_flat[idx] % Q
            bits.append(1 if (q1 <= rem < q3) else 0)

        header = np.packbits(bits[:32]).view(">u4")[0]
        if header != msg_len_bytes:
            continue

        data_bits = np.array(bits[32:32 + header * 8], dtype=np.uint8)
        msg = ''.join(chr(b) for b in np.packbits(data_bits))
        if len(msg) == msg_len_bytes and all(c in string.printable for c in msg):
            return key, msg

    return None, None
