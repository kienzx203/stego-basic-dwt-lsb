
from .embed import embed_message


__all__ = [
    "embed_message"
]
