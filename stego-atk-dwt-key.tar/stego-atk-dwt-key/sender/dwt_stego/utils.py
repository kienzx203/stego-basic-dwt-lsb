
import numpy as np

def str2bits(s: str) -> np.ndarray:
    """Convert UTF‑8 string to array of 0/1 bits."""
    return np.unpackbits(np.frombuffer(s.encode("utf-8"), dtype=np.uint8))

def bits2str(b: np.ndarray) -> str:
    """Convert array of bits back to UTF‑8 string."""
    return np.packbits(b).tobytes().decode("utf-8", errors="ignore")

def permute_idx(n: int, key: int) -> np.ndarray:
    """Return a pseudorandom permutation of range(n) keyed by `key`."""
    rng = np.random.default_rng(key)
    idx = np.arange(n)
    rng.shuffle(idx)
    return idx
