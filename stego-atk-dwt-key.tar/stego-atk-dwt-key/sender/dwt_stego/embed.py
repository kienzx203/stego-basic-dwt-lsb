"""Embed secret message in an image using DWT quantisation."""
import secrets
from pathlib import Path
from typing import Union
import numpy as np
import pywt
from PIL import Image
from .utils import str2bits, permute_idx

def embed_message(
    cover_path: Union[str, Path],
    msg: str,
    out_path: Union[str, Path],
    *,
    wavelet: str = "haar",
    level: int = 2,
    subband: str = "HL",
    Q: int = 20,
    key_bits: int = 128,
) -> int:
    """
    Hide `msg` inside `cover_path` and write stego image to `out_path`.

    Returns
    -------
    int
        The secret key (integer) that must be supplied to extract.
    """
    img = np.asarray(Image.open(cover_path).convert("L"), dtype=np.float32)

    coeffs = pywt.wavedec2(img, wavelet, level=level)
    # details is list of tuples (LH, HL, HH) for each level
    cA, *details = coeffs
    target_idx = {"LH": 0, "HL": 1, "HH": 2}[subband]
    band = details[level - 1][target_idx]

    bits = str2bits(msg)
    length_bits = np.unpackbits(
        np.array([len(bits) // 8], dtype=">u4").view(np.uint8)
    )
    payload = np.concatenate([length_bits, bits])
    if payload.size > band.size:
        raise ValueError("Message too long for this sub‑band")

    seed = secrets.randbits(key_bits)
    order = permute_idx(band.size, seed)

    flat = band.flatten()
    for k, bit in enumerate(payload):
        i = order[k]
        coeff = flat[i]
        base = np.round(coeff / Q) * Q
        flat[i] = base + (Q / 2 if bit else 0)

    # put back
    band_stego = flat.reshape(band.shape)
    details[level - 1] = list(details[level - 1])
    details[level - 1][target_idx] = band_stego
    coeffs_stego = [cA, *details]
    stego_img = pywt.waverec2(coeffs_stego, wavelet)
    stego_img = np.clip(stego_img, 0, 255).astype(np.uint8)

    Image.fromarray(stego_img).save(out_path)
    print(f"[*] Embedded {len(bits)//8} bytes -> {out_path}")
    print(f"[*] Secret key: {seed}")
    return seed
