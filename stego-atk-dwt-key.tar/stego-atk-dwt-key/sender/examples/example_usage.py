"""Command-line helper for quick testing & attacking."""
import sys, pathlib
sys.path.append(str(pathlib.Path(__file__).resolve().parent.parent))

import argparse
from dwt_stego import (
    embed_message
)

parser = argparse.ArgumentParser(description="DWT Stego Demo & Attack")
sub = parser.add_subparsers(dest="cmd", required=True)

# --- EMBED -------------------------------------------------------------
p_embed = sub.add_parser("embed", help="Hide a message")
p_embed.add_argument("cover")
p_embed.add_argument("output")
p_embed.add_argument("message")
p_embed.add_argument("--key-bits", type=int, default=128,
                     help="size of secret key in bits (default 128)")

args = parser.parse_args()

# ----------------- DISPATCH -------------------------------------------
if args.cmd == "embed":
    embed_message(args.cover, args.message, args.output, key_bits=args.key_bits)

elif args.cmd == "extract":
    txt = extract_message(args.stego, args.key, args.length)
    print("Recovered:", txt)

