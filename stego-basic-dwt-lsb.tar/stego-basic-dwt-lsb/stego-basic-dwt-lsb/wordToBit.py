def wordToBit(words):
    result = []
    for c in words:
        bits = bin(ord(c))[2:]
        bits = '00000000'[len(bits):] + bits
        result.extend([int(b) for b in bits])
    return result

print(wordToBit("B21DCAT009"))