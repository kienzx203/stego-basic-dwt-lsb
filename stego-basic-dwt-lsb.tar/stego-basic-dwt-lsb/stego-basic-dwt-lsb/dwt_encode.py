import cv2
import numpy as np
import pywt
import os
import copy

def wordToBit(words):
    result = []
    for c in words:
        bits = bin(ord(c))[2:]
        bits = '00000000'[len(bits):] + bits
        result.extend([int(b) for b in bits])
    return result

def intToBit(val):
    result = list(format(val, "b"))
    result = list(map(int, result))
    return result

def lsbVal(a, b):
    if a == b:
        return 0
    elif a == 1 and b == 0:
        return 2
    elif a == 0 and b == 1:
        return -2

def normalize_and_save(arr, name, output_dir):
    norm = cv2.normalize(arr, None, 0, 255, cv2.NORM_MINMAX)
    norm = np.uint8(norm)
    path = os.path.join(output_dir, f"{name}.png")
    cv2.imwrite(path, norm)

def dwt_encode_gray(img_path, message, wavelet='haar', end_tag='*', output_path="encoded_image.png", output_dir="./dwt_output"):
    os.makedirs(output_dir, exist_ok=True)

    img_color = cv2.imread(img_path)
    if img_color is None:
        raise FileNotFoundError(f"Cannot read image: {img_path}")
    img = cv2.cvtColor(img_color, cv2.COLOR_BGR2GRAY)

    message += end_tag
    bitMessage = wordToBit(message)
    bitLength = len(bitMessage)
    index = 0

    cA, (cH, cV, cD) = pywt.dwt2(img, wavelet)

    # Save original subbands
    normalize_and_save(cA, "LL_original", output_dir)
    normalize_and_save(cH, "LH", output_dir)
    normalize_and_save(cV, "HL", output_dir)
    normalize_and_save(cD, "HH", output_dir)

    cA_result = copy.deepcopy(cA)
    for i in range(cA.shape[0]):
        for j in range(cA.shape[1]):
            if index < bitLength:
                lsb = intToBit(int(cA[i, j]))[-2]
                cA_result[i, j] = cA[i, j] + lsbVal(bitMessage[index], lsb)
                index += 1

    normalize_and_save(cA_result, "LL_encoded", output_dir)

    encoded_img = pywt.idwt2((cA_result, (cH, cV, cD)), wavelet)
    encoded_img = np.clip(encoded_img, 0, 255)  # Ensure values are in 0–255
    encoded_img = np.uint8(encoded_img)

    full_encoded_path = os.path.join(output_dir, output_path)
    success = cv2.imwrite(full_encoded_path, encoded_img)
    print("Encoded image stats → min:", np.min(encoded_img), "max:", np.max(encoded_img))
    print("[DEBUG] Image write success:", success)
    print(f"[✓] Encoded image and subbands saved to: {output_dir}")

if __name__ == "__main__":
    input_image = "sea.png"              # Input image (will be converted to grayscale)
    message = "Hello from DWT!"
    encoded_image_path = "encoded_image.png"
    dwt_encode_gray(input_image, message, output_path=encoded_image_path)
