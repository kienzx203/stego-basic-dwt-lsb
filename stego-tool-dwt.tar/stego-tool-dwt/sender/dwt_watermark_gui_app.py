import streamlit as st
import numpy as np
import pywt
import cv2
from PIL import Image

def dwt2(image):
    image = image.astype(np.float64)
    return pywt.dwt2(image, 'haar')

def idwt2(coeffs):
    return np.clip(pywt.idwt2(coeffs, 'haar'), 0, 255).astype(np.uint8)

def text_to_bits(text):
    bits = []
    for char in text:
        binval = format(ord(char), '08b')
        bits.extend([int(b) for b in binval])
    return bits

def bits_to_text(bits):
    chars = []
    for b in range(0, len(bits), 8):
        byte = bits[b:b+8]
        if len(byte) < 8:
            continue
        chars.append(chr(int("".join(str(x) for x in byte), 2)))
    return ''.join(chars)

def embed_message(image, message, alpha=1.0):
    LL, (LH, HL, HH) = dwt2(image)
    HH_int = np.round(HH).astype(np.int32)
    hh_flat = HH_int.flatten()
    bits = text_to_bits(message)
    if len(bits) > len(hh_flat):
        raise ValueError("Message too long!")
    for i, bit in enumerate(bits):
        coeff = hh_flat[i]
        coeff = (coeff & ~1) | bit
        hh_flat[i] = coeff
    HH_mod = hh_flat.reshape(HH.shape).astype(np.float64)
    HH_blended = HH * (1 - alpha) + HH_mod * alpha
    return idwt2((LL, (LH, HL, HH_blended))), len(bits)

def extract_message(image, num_bits):
    _, (_, _, HH) = dwt2(image)
    hh_flat = np.round(HH).astype(np.int32).flatten()
    bits = [hh_flat[i] & 1 for i in range(num_bits)]
    return bits_to_text(bits)

st.title("🔐 DWT Watermarking with Message (LSB Accurate + Alpha)")

uploaded = st.file_uploader("📤 Upload grayscale image", type=["png", "jpg", "jpeg"])

if uploaded:
    img = Image.open(uploaded).convert("L")
    img_np = np.array(img.resize((256, 256)))

    st.image(img_np, caption="Original Image (256x256)", channels="GRAY")

    message = st.text_input("✍️ Enter message to hide", "hello world")
    alpha = st.slider("🔧 Adjust alpha (watermark strength)", 0.0, 150.0, 1.0, step=0.05)

    if st.button("👉 Embed message"):
        try:
            stego_img, bit_len = embed_message(img_np, message, alpha)
            st.image(stego_img, caption="Image with embedded message")
            st.session_state["stego_img"] = stego_img
            st.session_state["bit_len"] = bit_len
            _, buffer = cv2.imencode(".png", stego_img)
            st.download_button("📥 Download stego image", buffer.tobytes(), "stego_message.png", "image/png")
        except Exception as e:
            st.error(f"Error: {e}")

    if st.button("🔍 Extract message"):
        if "stego_img" in st.session_state:
            try:
                msg = extract_message(st.session_state["stego_img"], st.session_state["bit_len"])
                st.success(f"📤 Extracted message: {msg}")
            except Exception as e:
                st.warning(f"Cannot extract message: {e}")
        else:
            st.warning("No stego image available.")
