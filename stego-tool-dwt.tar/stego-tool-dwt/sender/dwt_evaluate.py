import cv2
import pywt
import numpy as np

def mse(img1, img2):
    return np.mean((img1 - img2) ** 2)

def psnr(img1, img2):
    mse_val = mse(img1, img2)
    if mse_val == 0:
        return float('inf')
    PIXEL_MAX = 255.0
    return 20 * np.log10(PIXEL_MAX / np.sqrt(mse_val))

def compare_images(original_path, encoded_path):
    # Read original and encoded images, convert to grayscale
    orig_color = cv2.imread(original_path)
    enc_color = cv2.imread(encoded_path)
    if orig_color is None or enc_color is None:
        raise FileNotFoundError("Unable to read input images.")

    orig_gray = cv2.cvtColor(orig_color, cv2.COLOR_BGR2GRAY)
    enc_gray = cv2.cvtColor(enc_color, cv2.COLOR_BGR2GRAY)

    # Compute overall PSNR
    psnr_val = psnr(orig_gray, enc_gray)
    print(f"[PSNR] Original vs Encoded Image: {psnr_val:.2f} dB")

    # Perform DWT on both images
    cA1, (cH1, cV1, cD1) = pywt.dwt2(orig_gray, 'haar')
    cA2, (cH2, cV2, cD2) = pywt.dwt2(enc_gray, 'haar')

    # Differences
    diff_LL = cA1 - cA2
    diff_LH = cH1 - cH2
    diff_HL = cV1 - cV2
    diff_HH = cD1 - cD2

    # Print MSE for each subband
    print("[MSE Subbands]")
    print(f"  LL: {np.mean(diff_LL**2):.4f}")
    print(f"  LH: {np.mean(diff_LH**2):.4f}")
    print(f"  HL: {np.mean(diff_HL**2):.4f}")
    print(f"  HH: {np.mean(diff_HH**2):.4f}")

if __name__ == "__main__":
    compare_images("sea.png", "dwt_output/encoded_image.png")
