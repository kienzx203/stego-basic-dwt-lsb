def find_xor_key_from_png(input_path):
    expected_header = bytes([0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A])  # PNG signature

    with open(input_path, "rb") as f_in:
        encrypted = bytearray(f_in.read(8))  # Đọc 8 byte đầu tiên

    for key in range(256):
        decrypted = bytearray([b ^ key for b in encrypted])
        if decrypted == expected_header:
            print(f"[✓] Found XOR key: {key}")
            return key

    print("[✗] No valid PNG header found with XOR brute-force.")
    return None

def xor_decrypt_file(input_path, output_path, key):
    with open(input_path, "rb") as f_in:
        data = bytearray(f_in.read())
    decrypted = bytearray([b ^ key for b in data])
    with open(output_path, "wb") as f_out:
        f_out.write(decrypted)
    print(f"[✓] Decrypted file saved to: {output_path}")

if __name__ == "__main__":
    input_file = "xor_encoded_file.png"
    output_file = "xor_image.png"

    xor_key = find_xor_key_from_png(input_file)
    if xor_key is not None:
        xor_decrypt_file(input_file, output_file, xor_key)
