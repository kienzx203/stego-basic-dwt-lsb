import cv2
import pywt

def intToBit(val):
    result = list(format(val, "b"))
    result = list(map(int, result))
    return result

def bitToWord(bits, end_tag='*'):
    chars = []
    for b in range(len(bits) // 8):
        byte = bits[b * 8:(b + 1) * 8]
        temp_chr = chr(int(''.join([str(bit) for bit in byte]), 2))
        if temp_chr == end_tag:
            break
        chars.append(temp_chr)
    return ''.join(chars)

def dwt_decode_gray(encoded_img_path, wavelet='haar', end_tag='*'):
    img = cv2.imread(encoded_img_path, cv2.IMREAD_GRAYSCALE)
    if img is None:
        raise FileNotFoundError(f"Cannot read image: {encoded_img_path}")

    cA, _ = pywt.dwt2(img, wavelet)

    bits = []
    for i in range(cA.shape[0]):
        for j in range(cA.shape[1]):
            val = int(cA[i, j])
            bit = intToBit(val)
            bits.append(bit[-2] if len(bit) >= 2 else 0)

    message = bitToWord(bits, end_tag=end_tag)
    return message

if __name__ == "__main__":
    msg = dwt_decode_gray("dwt_output/xor_image.png")
    print("Recovered message:", msg)
