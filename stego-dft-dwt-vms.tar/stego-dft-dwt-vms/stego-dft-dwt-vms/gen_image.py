import os
import cv2
import pywt
import numpy as np
from PIL import Image

def str2bits(s):
    return [int(b) for c in s.encode("utf-8") for b in format(c, "08b")]

def embed_dwt(img_array, bits, Q=20):
    coeffs = pywt.dwt2(img_array.astype(np.float32), 'haar')
    cA, (cH, cV, cD) = coeffs
    flat = cV.flatten()
    for i, bit in enumerate(bits):
        base = np.round(flat[i] / Q) * Q
        flat[i] = base + (Q / 2 if bit else 0)
    cV_embed = flat.reshape(cV.shape)
    coeffs_embed = (cA, (cH, cV_embed, cD))
    return np.clip(pywt.idwt2(coeffs_embed, 'haar'), 0, 255).astype(np.uint8)

# Load base image (lena.png) from current directory
img = Image.open("lena.png").convert("L").resize((128, 128))
img_np = np.array(img)
bits = str2bits("HiddenMsg")

os.makedirs("clean", exist_ok=True)
os.makedirs("stego", exist_ok=True)

for i in range(50):
    cv2.imwrite(f"clean/clean_{i}.png", img_np)
    stego = embed_dwt(img_np, bits)
    cv2.imwrite(f"stego/stego_{i}.png", stego)
