import cv2
import numpy as np
import pywt
from scipy.stats import skew, kurtosis
import joblib
import sys

def compute_features(img_path):
    img = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)
    coeffs = pywt.dwt2(img, 'haar')
    subbands = [coeffs[0], *coeffs[1]]
    features = []
    for sb in subbands:
        flat = sb.flatten()
        features += [
            np.mean(flat),
            np.var(flat),
            skew(flat, nan_policy='omit'),
            kurtosis(flat, nan_policy='omit')
        ]
    return np.array(features).reshape(1, -1)

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python predict_wms.py <image_path>")
        exit(1)

    clf = joblib.load("wms_model.pkl")  # Load the trained model

    feat = compute_features(sys.argv[1])
    pred = clf.predict(feat)[0]

    print("🔍 Result:", "Stego image (STEGANO)" if pred == 1 else "Clean image (CLEAN)")
