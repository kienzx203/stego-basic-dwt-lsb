import pywt
import cv2
import numpy as np
import os
import pandas as pd
from scipy.stats import skew, kurtosis

def compute_wms(image_path):
    img = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    coeffs = pywt.dwt2(img, 'haar')
    subbands = [coeffs[0], *coeffs[1]]  # LL, LH, HL, HH

    features = []
    for band in subbands:
        flat = band.flatten()
        features += [np.mean(flat), np.var(flat), skew(flat), kurtosis(flat)]
    return features

def extract_features(folder, label):
    data = []
    for fname in os.listdir(folder):
        path = os.path.join(folder, fname)
        if path.endswith(".png"):
            feat = compute_wms(path)
            feat.append(label)
            data.append(feat)
    return data

if __name__ == "__main__":
    clean = extract_features("clean", 0)
    stego = extract_features("stego", 1)

    all_data = clean + stego
    cols = [f"{s}_{m}" for s in ["LL","LH","HL","HH"] for m in ["mean","var","skew","kurt"]]
    df = pd.DataFrame(all_data, columns=cols+["label"])
    df.to_csv("wms_features.csv", index=False)
    print("✓ Saved feature set to wms_features.csv")
